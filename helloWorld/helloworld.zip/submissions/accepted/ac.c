#include<stdio.h>

int main(){
    int t;
    scanf("%d", &t);
    printf("Hello world!\n");
}