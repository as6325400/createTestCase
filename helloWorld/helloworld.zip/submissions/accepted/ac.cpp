#include <bits/stdc++.h>
#define int long long
 
using namespace std;
 

signed main(){
    int tt;
    cin >> tt;
    cout << "Hello world!" << '\n';
}